﻿namespace P01_RawData
{
    public class RawData
    {
        public static void Main()
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }
}
